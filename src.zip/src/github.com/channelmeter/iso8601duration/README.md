iso8601duration
===============

ISO8601 Duration Parser for Golang

Adapted from http://github.com/BrianHicks/finch
